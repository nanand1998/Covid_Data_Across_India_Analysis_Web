import React, { useState, useEffect } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

const StateWiseBarGraph = function({ casesData }) {
    const [data, setData] = useState([]);

    useEffect(() => {
        const formattedData = [];
        for (let key in casesData) {
            formattedData.push({
                state: key,
                confirmed: casesData[key].total.tested
            });
        }
        setData(formattedData);
    }, [casesData]);

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <div style={{ textAlign: 'center' }}>
                <p style={{ fontWeight: 'bold' }}>Cases Count region wise</p>
                <BarChart
                    width={1000}  // Increased width
                    height={300} // Increased height
                    data={data}
                    margin={{
                        top: 20, right: 30, left: 20, bottom: 5,
                    }}
                >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="state" interval={0} angle={-45} textAnchor="end" /> {/* Ensure all labels are shown */}
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="confirmed" fill="#FF8C00" />
                </BarChart>
            </div>
        </div>
    );
}

export default StateWiseBarGraph;
