import React, { useEffect, useState } from "react";
import StateWiseData from "./StateWiseData";

const StatesNavbar = function({ casesData }) {
    const [selectedStateCode, setSelectedStateCode] = useState("");
    const [selectedStateData, setSelectedStateData] = useState(null);
    const [dropdownOptions, setDropdownOptions] = useState([]);

    useEffect(() => {
        if (casesData && Object.keys(casesData).length > 0) {
            const options = Object.keys(casesData).map((stateCode) => (
                <option key={stateCode} value={stateCode}>
                    {getStateName(stateCode)}
                </option>
            ));
            setDropdownOptions(options);
        }
    }, [casesData]);

    const getStateName = (stateCode) => {
        return stateCode; // Replace with actual state name retrieval logic
    };

    const handleDropdownChange = (event) => {
        const selectedStateCode = event.target.value;
        setSelectedStateCode(selectedStateCode);
        const selectedData = casesData[selectedStateCode];
        setSelectedStateData(selectedData);
        console.log(selectedStateCode, selectedData);
    };

    return (
        <div style={{ textAlign: 'center' }}>
            <div className="dropdown" style={{ display: 'inline-block', margin: '20px' }}>
                <select
                    className="form-select"
                    onChange={handleDropdownChange}
                    value={selectedStateCode}>
                    <option value="">Choose State/Region</option>
                    {dropdownOptions}
                </select>
            </div>
            <br />
            <StateWiseData
                selectedStateCode={selectedStateCode}
                selectedStateData={selectedStateData}
            />
        </div>
    );
};

export default StatesNavbar;
