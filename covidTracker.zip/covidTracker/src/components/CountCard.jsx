import React from 'react';

const CountCard = ({ casesData, data }) => {
    const showCasesData = () => {
        let confirmedCount = 0;
        let recoveredCount = 0;
        let deceasedCount = 0;
        let vaccinatedCount = 0;

        for (let key in casesData) {
            const total = casesData[key].total;
            confirmedCount += total.confirmed || 0;
            deceasedCount += total.deceased || 0;
            recoveredCount += total.recovered || 0;
            vaccinatedCount += (total.vaccinated1 || 0) + (total.vaccinated2 || 0);
        }

        return [
            confirmedCount.toLocaleString(),
            recoveredCount.toLocaleString(),
            deceasedCount.toLocaleString(),
            vaccinatedCount.toLocaleString()
        ];
    };

    const showCasesData2 = () => {
        console.log(data, casesData);
    };

    return (
        <div style={{ padding: '20px', textAlign: 'center' }}>
            <h2 style={{ marginBottom: '20px', fontSize: '28px', fontFamily: 'Arial, sans-serif' }}>Covid Cases Across India</h2>
            <div style={{ display: 'flex', justifyContent: 'center' }}>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px', justifyContent: 'center' }}>
                    <div
                        className="card"
                        onClick={showCasesData2}
                        style={{
                            border: '1px solid #ddd',
                            padding: '20px',
                            borderRadius: '20px',
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                            flex: '1 1 calc(25% - 40px)',
                            minWidth: '200px',
                            maxWidth: '300px',
                            textAlign: 'center',
                            cursor: 'pointer'
                        }}
                    >
                        <h4 style={{ fontSize: '16px', color: 'darkgrey' }}>Total Cases</h4>
                        <h4 style={{ color: 'blue', fontSize: '24px' }}>{showCasesData()[0]}</h4>
                    </div>
                    <div
                        className="card"
                        style={{
                            border: '1px solid #ddd',
                            padding: '20px',
                            borderRadius: '20px',
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                            flex: '1 1 calc(25% - 40px)',
                            minWidth: '200px',
                            maxWidth: '300px',
                            textAlign: 'center'
                        }}
                    >
                        <h4 style={{ fontSize: '16px', color: 'darkgrey' }}>Recovered</h4>
                        <h4 style={{ color: 'rgb(0, 204, 0)', fontSize: '24px' }}>{showCasesData()[1]}</h4>
                    </div>
                    <div
                        className="card"
                        style={{
                            border: '1px solid #ddd',
                            padding: '20px',
                            borderRadius: '20px',
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                            flex: '1 1 calc(25% - 40px)',
                            minWidth: '200px',
                            maxWidth: '300px',
                            textAlign: 'center'
                        }}
                    >
                        <h4 style={{ fontSize: '16px', color: 'darkgrey' }}>Deceased</h4>
                        <h4 style={{ color: 'red', fontSize: '24px' }}>{showCasesData()[2]}</h4>
                    </div>
                    <div
                        className="card"
                        style={{
                            border: '1px solid #ddd',
                            padding: '20px',
                            borderRadius: '20px',
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                            flex: '1 1 calc(25% - 40px)',
                            minWidth: '200px',
                            maxWidth: '300px',
                            textAlign: 'center'
                        }}
                    >
                        <h4 style={{ fontSize: '16px', color: 'darkgrey' }}>Vaccinated</h4>
                        <h4 style={{ color: 'darkgrey', fontSize: '24px' }}>{showCasesData()[3]}</h4>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CountCard;
