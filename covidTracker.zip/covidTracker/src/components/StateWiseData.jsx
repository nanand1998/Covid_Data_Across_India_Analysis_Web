import React, { useEffect } from "react";

const StateWiseData = ({ selectedStateCode, selectedStateData }) => {
    useEffect(() => {
        console.log("StateWiseData", selectedStateCode, selectedStateData);
    }, [selectedStateCode, selectedStateData]);

    return (
        <div>
            {selectedStateCode && selectedStateData ? (
                <div>
                    <p>Selected State/Region: {selectedStateCode}</p>
                    <div className="card-container" style={{ display: 'flex', flexWrap: 'wrap', gap: '10px', justifyContent: 'center' }}>
                        <div className="card" style={{
                            border: '1px solid #ddd',
                            padding: '10px',
                            borderRadius: '12px',
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                            flex: '1 1 calc(25% - 20px)',
                            minWidth: '120px',
                            maxWidth: '150px',
                            textAlign: 'center',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center'
                        }}>
                            <h3 style={{ fontSize: '14px' }}>Total Cases</h3>
                            <p style={{ fontSize: '16px', color: 'blue' }}>{(selectedStateData.total.confirmed)}</p>
                        </div>
                        <div className="card" style={{
                            border: '1px solid #ddd',
                            padding: '10px',
                            borderRadius: '12px',
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                            flex: '1 1 calc(25% - 20px)',
                            minWidth: '120px',
                            maxWidth: '150px',
                            textAlign: 'center',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center'
                        }}>
                            <h3 style={{ fontSize: '14px' }}>Recovered</h3>
                            <p style={{ fontSize: '16px', color: 'rgb(0, 204, 0)' }}>{selectedStateData.total.recovered}</p>
                        </div>
                        <div className="card" style={{
                            border: '1px solid #ddd',
                            padding: '10px',
                            borderRadius: '12px',
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                            flex: '1 1 calc(25% - 20px)',
                            minWidth: '120px',
                            maxWidth: '150px',
                            textAlign: 'center',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center'
                        }}>
                            <h3 style={{ fontSize: '14px' }}>Deceased</h3>
                            <p style={{ fontSize: '16px', color: 'red' }}>{selectedStateData.total.deceased}</p>
                        </div>
                        <div className="card" style={{
                            border: '1px solid #ddd',
                            padding: '10px',
                            borderRadius: '12px',
                            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
                            flex: '1 1 calc(25% - 20px)',
                            minWidth: '120px',
                            maxWidth: '150px',
                            textAlign: 'center',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center'
                        }}>
                            <h3 style={{ fontSize: '14px' }}>Vaccinated</h3>
                            <p style={{ fontSize: '16px', color: 'darkgrey' }}>{selectedStateData.total.vaccinated1 + selectedStateData.total.vaccinated2}</p>
                        </div>
                    </div>
                </div>
            ) : (
                <p>Please select State/Region</p>
            )}
        </div>
    );
};

export default StateWiseData;
