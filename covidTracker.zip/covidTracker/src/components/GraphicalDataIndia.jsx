import React, { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

function GraphicalDataIndia({ data }) {
    const [chartData, setChartData] = useState([]);

    const showGraphicalData = () => {
        let dates = [];
        let cases = [];
        for (let state in data) {
            for (let dateKey in data[state].dates) {
                let date = dateKey;
                let confirmedCases = data[state].dates[dateKey] && data[state].dates[dateKey].total && data[state].dates[dateKey].total.confirmed;
                if (confirmedCases !== undefined) {
                    dates.push(date);
                    cases.push(confirmedCases);
                }
            }
        }
        // Create an array of objects with 'date' and 'cases' properties for chart data
        const chartData = dates.map((date, index) => ({ date, cases: cases[index] }));
        setChartData(chartData);
    };

    useEffect(() => {
        showGraphicalData();
    }, [data]);

    return (
        <div style={{ width: '60%', height: 300, margin: '0 auto' }}>
            <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                    <CartesianGrid stroke="#ccc" />
                    <XAxis dataKey="date"  />
                    <YAxis  />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="cases" stroke="#8884d8" />
                </LineChart>
            </ResponsiveContainer>
        </div>
    )
}

export default GraphicalDataIndia;
