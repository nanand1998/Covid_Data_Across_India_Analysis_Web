import React, { useState, useEffect } from "react";
import CountCard from "./CountCard";
import StatesNavbar from "./StatesNavbar";
import GraphicalDataIndia from "./GraphicalDataIndia";
import StateWiseBarGraph from "./StateWiseBarGraph";

const ParentComponent = function(){

    const [data, setData] = useState(null);
    const [casesData, setCasesData] = useState(null);

    useEffect(()=>{
        fetch('https://data.covid19india.org/v4/min/timeseries.min.json')
            .then((response) => {
                return response.json();})
            .then((data)=>{
                setData(data); //here data is stored in setData
            })
            .catch((error)=>{
                console.log("Error fetching data:", error);
            })  
            
        fetch('https://data.covid19india.org/v4/min/data.min.json')
            .then((response) => {
                return response.json();
            })
            .then((data)=>{
                setCasesData(data); //here data is stored in setCasesData
            })
            .catch((error)=>{
                console.log("Error fetching data:", error);
            })      
    })

    return(
        <>
            <CountCard data = {data} casesData = {casesData}/>
            <StatesNavbar casesData = {casesData}/>
            <GraphicalDataIndia data = {data}/>
            <StateWiseBarGraph data = {data} casesData = {casesData}/>
        </>
    )
}

export default ParentComponent;