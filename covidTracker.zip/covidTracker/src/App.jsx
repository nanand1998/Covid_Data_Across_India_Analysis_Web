import React, {useState } from 'react'
import './App.css'
import CountCard from './components/CountCard'
import StatesNavbar from './components/StatesNavbar'
import ParentComponent from './components/ParentComponent'


function App() {

  return (
    <>
    <ParentComponent/>
    </>
  )
}

export default App
